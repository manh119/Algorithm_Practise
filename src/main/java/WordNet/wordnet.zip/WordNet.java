import edu.princeton.cs.algs4.Digraph;
import edu.princeton.cs.algs4.In;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;


public class WordNet {
    private final HashMap<String, Set<Integer>> map_name_setId;
    private final HashMap<Integer, Set<String>> map_id_setName;
    private final SAP sap;
    // constructor takes the name of the two input files
    public WordNet(String synsets, String hypernyms) {
        map_id_setName = new HashMap<>();
        map_name_setId = new HashMap<>();
        In syssetsInput = new In(synsets);
        In hypernymsInput = new In(hypernyms);

        while (syssetsInput.hasNextLine()) {
            String line = syssetsInput.readLine();
            String[] s = line.split(",", 0);
            int id = Integer.parseInt(s[0]);
            String list_name = s[1];
            // TODO : build 2 map
            String[] names = list_name.split(" ", 0);
            Set<String> setName = new HashSet<>();
            for (String name : names)
                setName.add(name);
            map_id_setName.put(id,setName);
            //
            for (String name : names) {
                Set<Integer> set_id = map_name_setId.getOrDefault(name, new HashSet<>());
                set_id.add(id);
                map_name_setId.put(name, set_id);
            }
        }
//        System.out.println("-----------");
//        System.out.println(map_id_setName.toString());
//        System.out.println("-----------");
//        System.out.println(map_name_setId.toString());

        // TODO : read input to hashMap
        HashMap<Integer, Set<Integer>> map_hypernyms = new HashMap<>();
        while(hypernymsInput.hasNextLine()) {
            String line = hypernymsInput.readLine();
            String[] nums = line.split(",", 0);
            int id = Integer.parseInt(nums[0]);
            Set<Integer> setHyper = new HashSet<>();
            for(int i = 1; i < nums.length; i++)
                setHyper.add(Integer.parseInt(nums[i]));
            map_hypernyms.put(id, setHyper);
        }
//        System.out.println("-----------");
//        System.out.println(map_hypernyms.toString());

        // TODO : build graph from hashMap
        Digraph G = new Digraph(map_hypernyms.size());
        for(int i = 0; i < G.V(); i++) {
            Set<Integer> setE = map_hypernyms.get(i);
            for (Integer e : setE)
                G.addEdge(i, e);
        }
//        System.out.println("------------");
//        System.out.println(G.toString());

        sap = new SAP(G);
    }

    // returns all WordNet.WordNet nouns
    public Iterable<String> nouns() {
        return map_name_setId.keySet();
    }

    // is the word a WordNet.WordNet noun?
    public boolean isNoun(String word) {
        return map_name_setId.containsKey(word);
    }

    // distance between nounA and nounB (defined below)
    public int distance(String nounA, String nounB) {
        Set<Integer> setIdNounA = map_name_setId.get(nounA);
        Set<Integer> setIdNounB = map_name_setId.get(nounB);
        return sap.length(setIdNounA, setIdNounB);
    }

    // a synset (second field of synsets.txt) that is the common ancestor of nounA and nounB
    // in a shortest ancestral path (defined below)
    public String sap(String nounA, String nounB) {
        Set<Integer> setIdNounA = map_name_setId.get(nounA);
        Set<Integer> setIdNounB = map_name_setId.get(nounB);
        int id_result = sap.ancestor(setIdNounA, setIdNounB);
        Set<String> setName =  map_id_setName.get(id_result);
        String s = "";
        for(String name : setName)
            s = name + " ";
        return s;
    }

    // do unit testing of this class
    public static void main(String[] args) {
        WordNet wordNet = new WordNet("wordnet/synsets.txt", "wordnet/hypernyms.txt");
        System.out.println(wordNet.distance("edible_fruit", "physical_entity"));
    }
}