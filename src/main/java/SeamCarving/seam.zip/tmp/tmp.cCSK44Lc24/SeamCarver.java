
import edu.princeton.cs.algs4.Picture;
import java.awt.Color;
import java.util.Arrays;


public class SeamCarver {
    private Picture picture;
    final private double[][] energies;
    final private int width;
    final private int height;

    // create a seam carver object based on the given picture
    public SeamCarver(Picture picture) {
        this.picture = new Picture(picture);
        width = picture.width();
        height = picture.height();
        energies = new double[width][height];
        for (int i = 0; i < width; i++) {
            for (int j = 0; j < height; j++) {
                energies[i][j] = energyXY(i, j);
            }
        }

    }

    // current picture
    public Picture picture() {
        return picture;
    }

    // energy of pixel at column x and row y
    public double energy(int x, int y) {
        return energies[x][y];
    }

    private double energyXY(int x, int y) {
        if (x == 0 || y == 0 || x == width - 1 || y == height - 1)
            return 1000;
        return Math.sqrt(squareGradientX(x, y) + squareGradientY(x, y));
    }

    private double squareGradientX(int x, int y) {
        Color c1 = picture.get(x - 1, y);
        Color c2 = picture.get(x + 1, y);
        int deltaR = c1.getRed() - c2.getRed();
        int deltaG = c1.getGreen() - c2.getGreen();
        int deltaB = c1.getBlue() - c2.getBlue();
        return deltaR * deltaR + deltaB * deltaB + deltaG * deltaG;
    }

    private double squareGradientY(int x, int y) {
        Color c1 = picture.get(x, y - 1);
        Color c2 = picture.get(x, y + 1);
        int deltaR = c1.getRed() - c2.getRed();
        int deltaG = c1.getGreen() - c2.getGreen();
        int deltaB = c1.getBlue() - c2.getBlue();
        return deltaR * deltaR + deltaB * deltaB + deltaG * deltaG;
    }


    // TODO : instance object itself in its class ???
    // sequence of indices for horizontal seam
    public int[] findHorizontalSeam() {
        Picture transposed = new Picture(picture.height(), picture.width());
        for (int x = 0; x < picture.width(); x++) {
            for (int y = 0; y < picture.height(); y++) {
                transposed.setRGB(y, x, picture.getRGB(x, y));
            }
        }
        SeamCarver s = new SeamCarver(transposed);
        return s.findVerticalSeam();
    }


    // sequence of indices for vertical seam
    public int[] findVerticalSeam() {
        double[][] distTo = new double[width][height];
        int[][] edgeTo = new int[width][height];

        // Initialize distance array
        for (int x = 0; x < width; x++) {
            Arrays.fill(distTo[x], Double.POSITIVE_INFINITY);
        }

        // Initialize the top row of distTo with energies
        for (int x = 0; x < width; x++) {
            distTo[x][0] = energies[x][0];
        }

        // Topological sort
        for (int y = 0; y < height - 1; y++) {
            for (int x = 0; x < width; x++) {
                relax(x, y, distTo, edgeTo);
            }
        }

        // Find the minimum seam
        int minX = 0;
        for (int x = 1; x < width; x++) {
            if (distTo[x][height - 1] < distTo[minX][height - 1]) {
                minX = x;
            }
        }

        // Reconstruct seam from edgeTo
        int[] seam = new int[height];
        for (int y = height - 1; y >= 0; y--) {
            seam[y] = minX;
            minX = edgeTo[minX][y];
        }
        return seam;
    }

    private void relax(int x, int y, double[][] distTo, int[][] edgeTo) {
        for (int dx = -1; dx <= 1; dx++) {
            int nextX = x + dx;
            if (nextX >= 0 && nextX < width) {
                if (distTo[x][y] + energies[nextX][y + 1] < distTo[nextX][y + 1]) {
                    distTo[nextX][y + 1] = distTo[x][y] + energies[nextX][y + 1];
                    edgeTo[nextX][y + 1] = x;
                }
            }
        }
    }


    public int width() {
        return width;
    }

    // height of current picture
    public int height() {
        return height;
    }


    // remove horizontal seam from current picture
    public void removeHorizontalSeam(int[] seam) {
        if (seam == null || this.height() <= 1 || seam.length != this.width()) {
            throw new IllegalArgumentException();
        }

        Picture newPicture = new Picture(this.width(), this.height() - 1);

        int prevSeam = seam[0];

        for (int x = 0; x < this.width(); x++) {
            if (Math.abs(seam[x] - prevSeam) > 1 || seam[x] < 0 || seam[x] >= this.height()) {
                throw new IllegalArgumentException();
            }
            prevSeam = seam[x];

            for (int y = 0; y < this.height(); y++) {
                if (seam[x] == y) continue;

                Color color = this.picture.get(x, y);
                newPicture.set(x, seam[x] > y ? y : y - 1, color);
            }
        }

        this.picture = newPicture;
    }

    // remove vertical seam from current picture
    public void removeVerticalSeam(int[] seam) {
        if (seam == null || this.width() <= 1 || seam.length != this.height()) {
            throw new IllegalArgumentException();
        }

        Picture newPicture = new Picture(this.width() - 1, this.height());

        int prevSeam = seam[0];

        for (int y = 0; y < this.height(); y++) {
            if (Math.abs(seam[y] - prevSeam) > 1 || seam[y] < 0 || seam[y] >= this.width()) {
                throw new IllegalArgumentException();
            }
            prevSeam = seam[y];

            for (int x = 0; x < this.width(); x++) {
                if (seam[y] == x) continue;

                Color color = this.picture.get(x, y);
                newPicture.set(seam[y] > x ? x : x - 1, y, color);
            }
        }

        this.picture = newPicture;
    }

    //  unit testing (optional)
    public static void main(String[] args) {
        SeamCarver seam;
        Picture picture = new Picture("seam/6x5.png");
        seam = new SeamCarver(picture);
        seam.findVerticalSeam();
    }

}
